import { HomePage } from "./pages/HomePage";

import "./components/styles/index.scss";


function App() {
  return (
    <>
      <HomePage />
    </>
  )
}

export default App
